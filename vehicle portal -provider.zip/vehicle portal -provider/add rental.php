<?php
include 'connection.php';
$name=$_POST['name'];
$price=$_POST['price'];
$vehicle=$_POST['vehicle_type'];
$gear=$_POST['type_of_gear'];
$color=$_POST['color_of_vehicle'];
$seat=$_POST['seats_of_vehicle'];
$fuel=$_POST['fuel_of_vehicle'];
$location=$_POST['location'];
// $RC=$_POST['RC'];
$RC=$_FILES['photo']['name'];
    if($image !=""){
        $filearray=pathinfo($_FILES['RC']['name']);

        $file1=rand();
        $file_ext=$filearray['extension'];


        $filenew = $file1 . "." .$file_ext;
        move_uploaded_file($_FILES['RC']['tmp_name'], "../image/" . $filenew);
    }
 else
 {
    echo"<script>alert('try again....')</script>";
 }
$insurance = $_POST['insurance'];
$dl=$_POST['driving_licence'];
$uploadphoto=$_POST['upload_photo'];
$sql = mysqli_query($con, "INSERT INTO add_rental_vehicles(name,price,vehicle_type,type_of_gear,color_of_vehicle,seats_of_vehicle,fuel_of_vehicle,location,RC,insurance,driving_licence,upload_photo)VALUES('$name','$price','$vehicle','$gear','$color','$seat','$fuel','$location','$filenew','$insurance','$dl','$uploadphoto')");

if ($sql)
{
   
    $myarray['message'] = 'successfully added';

} else {
    $myarray['message'] = 'failed';
}
echo json_encode($myarray);
?>