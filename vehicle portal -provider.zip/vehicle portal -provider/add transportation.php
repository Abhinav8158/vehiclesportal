<?php
include 'connection.php';
$vehicle=$_POST['vehicle'];
$seat=$_POST['seat']
$location=$_POST['location'];
$RC  =$_POST['RC'];
$insurance = $_POST['insurance'];
$dl = $_POST['dl'];
$uploadphoto= $_POST['upload_photo'];
$sql = mysqli_query($con, "INSERT INTO add_transportation_vehicle(vehicle,seat, location,RC,insurance,dl,upload_photo)VALUES('$vehicle','$seat''$location','$RC','$insurance','$dl','$uploadphoto')");

if ($sql)
{
   
    $myarray['message'] = 'added';

} else {
    $myarray['message'] = 'failed';
}
echo json_encode($myarray);
?>